﻿วิธี Setup Audio.h/Audio.cpp
1. Copy Floder sdl_mixer ไปไว้ใน project
2. Setup Include และ lib ใน Floder นั้น (libให้ใช้ x86)
3. Copy ไฟล์ .dll ทุกอันใน Floder x86 ไปใส่ใน project ด้วย
4. เพิ่มไฟล์ Audio.h/Audio.cpp แล้วใช้งานตามปกติ

วิธีใช้งาน Audio.h/Audio.cpp

1. เริ่มด้วย #include "Audio.h"

2. ในไฟล์ main แก้จาก
if (SDL_Init(SDL_INIT_VIDEO) < 0)
เป็น
if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0)

3. สร้างตัวแปรคุมเสียงแล้วสั่ง init()
AudioEngine audio;
audio.init();


4. โหลดไฟล์เสียงที่ต้องการลงไปแล้วแต่ประเภทที่ใช้งาน การสั่ง load ทำเพียงครั้งเดียวต่อ 1 ไฟล์ไม่จำเป็นต้องทำซ้ำ
Music music = audio.loadMusic("sample.wav");
SoundEffect sound = audio.loadSoundEffect("sample3.ogg");
โดยมีประเภทดังนี้
SoundEffect จะใช้กรณีเล่นเสียงตาม Effect ต่างๆเช่น ยิงปืน ระเบิด สามารถเปิดหลายๆตัวพร้อมกันได้
Music ใช้เป็นเป็น BackGroundMusic เปิดได้แค่ทีละ 1 ตัวเท่านั้น

5. สั่ง play()
music.play();
sound.play();
โดย Function play(int loop) ของทั้ง 2 ตัวรับพารามิเตอร์ int 1 ตัวเป็นจำนวนรอบที่จะให้เสียงนั้นเล่น หากใส่ -1 จะเป็นการเล่นแบบไม่รู้จบ 0 คือเล่นรอบเดียว (ค่าเริ่มต้นคือ 0)

Music จะมี Function เพิ่มมาอีก 3 อันคือ
pause() หยุดเล่น Music นั้นชั่วคราว
resume() กลับมาเล่น Music ที่หยุดไปจาก pause()
stop() สั่งจบ Music นั้นๆ

สกุลไฟล์ที่สามารถใช้ได้ (เท่าที่ลองแล้วติด)
.wav
.mp3
.wav

Credit : https://www.youtube.com/watch?v=vKwDGQXL29U